from datetime import datetime
from cybervpn import *
from telethon import events, Button
import subprocess
import requests

# Fungsi untuk mengambil informasi pengguna, lokasi, dan statistik akun
@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)
    first_name = event.sender.first_name
    last_name = event.sender.last_name if event.sender.last_name else ""

    # Mendapatkan waktu saat ini
    current_time = datetime.now().strftime("%H:%M:%S")  # Format HH:MM:SS

    # Fungsi untuk mendapatkan waktu aktif VPS (Contoh, sesuaikan dengan kebutuhan)
    def get_vps_active_days():
        try:
            # Contoh: Ambil informasi ini dari server/database Anda
            active_days = subprocess.check_output("uptime -p", shell=True).decode("utf-8").strip()  # Contoh
            return active_days
        except Exception as e:
            return "Unknown"

    vps_active_days = get_vps_active_days()

    # Memeriksa apakah pengguna terdaftar
    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            # Mengambil informasi lokasi dengan aman
            try:
                location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            except requests.exceptions.RequestException as e:
                print(f"Error fetching location info: {e}")
                location_info = {"country": "Unknown", "region": "Unknown", "city": "Unknown", "isp": "Unknown"}

            # Mengambil statistik akun
            ssh_count = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vless_count = subprocess.check_output('cat /etc/vless/.vless.db | grep "###" | wc -l', shell=True).decode("ascii").strip()
            trojan_count = subprocess.check_output('cat /etc/trojan/.trojan.db | grep "###" | wc -l', shell=True).decode("ascii").strip()

            city = location_info.get("city", "Unknown City")

            # Untuk pengguna biasa
            if level == "user":
                member_inline = [

    [Button.inline("𝗦𝗦𝗛-𝗪𝗦 🛡️", "ssh"), Button.inline("𝗩𝗠𝗘𝗦𝗦 📶", "vmess-member")],
    [Button.inline("𝗗𝗘𝗣𝗢𝗦𝗜𝗧 💸", "topup")]
]
                member_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━**
       **≡  MEMBER BOT MENU  ≡**
**━━━━━━━━━━━━━━━━━━━━━━**
**🔹 Host Details:**
**💻 Host:** `{DOMAIN}`
**🌐 ISP:** `{location_info["isp"]}`
**🌍 Country:** `{location_info["country"]}`
**🏙️ City:** `{city}`
**━━━━━━━━━━━━━━━━━━━━━━**
**💎 Special Offer!**
**🎁 Get a bonus with every deposit!**
**🎉 Deposit and earn rewards!**
**━━━━━━━━━━━━━━━━━━━━━━**
**💵 Price: 💸 Rp. 10,000**
**🆔 Your ID: 🆔** `{user_id}`
**👥 Total Users: 👥 {get_user_count()}**
**💰 Your Balance: 💰 Rp.{saldo_aji}**
**━━━━━━━━━━━━━━━━━━━━━━**
**📞 Contact Support:**
**📩 Support Team:** @DaffVpnStore
**📧 Email:** `pratamadaffa63136@gmail.com`
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
                # Kirim gambar dan pesan sekaligus
                await event.respond(

                    message=member_msg, 
                    buttons=member_inline
                )
                
 # Untuk admin
            elif level == "admin":
                admin_inline = [

    [Button.inline("𝗦𝗦𝗛-𝗪𝗦 🔑", "ssh"), Button.inline("𝗩𝗠𝗘𝗦𝗦 🌍", "vmess")],
    [Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡 🛡️", "trojan"), Button.inline("𝗩𝗟𝗘𝗦𝗦 🌍", "vless")],
    [Button.inline("𝗦𝗘𝗧𝗜𝗡𝗚 ⚙️", "setting"), Button.inline("𝗨𝗦𝗘𝗥 👥", "show-user")],
    [Button.inline("𝗛𝗔𝗣𝗨𝗦 ❌", "delete-member"), Button.inline("𝗔𝗗𝗗 𝗔𝗗𝗠𝗜𝗡 👥", "registrasi-member")]
]
                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
    **≡       MENU BOT SIMPLE        ≡** 
**━━━━━━━━━━━━━━━━━━━━━━━**
**»Host Information:**
**»Host:** `{DOMAIN}`
**»ISP:** `{location_info["isp"]}`
**»Location:** `{location_info["country"]}`
**»City:** `{city}`
**━━━━━━━━━━━━━━━━━━━━━━━**
**»Account Information:**
**»SSH :** `{ssh_count} Account`
**»VMESS :** `{vmess_count} Account`
**»TROJAN :** `{trojan_count} Account`
**━━━━━━━━━━━━━━━━━━━━━━━**
**»Admin Information:**
**🆔 Your ID:** `{user_id}`
**👥 Total Users: {get_user_count()}**
**💰 Balance: Rp.{saldo_aji}**
**━━━━━━━━━━━━━━━━━━━━━**
**»Owner** @DaffVpnStore
"""
                # Kirim gambar dan pesan sekaligus
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
f'**═════════════════════════**\n'
f'**Selamat Datang di DP75X Vpn Store 🎉**\n'
f'**Nama:** {first_name} {last_name}\n'
f'**ID Pengguna:** `{user_id}`\n'
f'**Total Admin:** `{get_user_count()}`\n'
f'**═════════════════════════**\n'
f'**💻PAKET VPS SGDO 🇸🇬**\n'
f'**1️⃣GB RAM, 1 Core:** `IDR 35.000` 🇸🇬\n'
f'**2️⃣GB RAM, 1 Core:** `IDR 40.000` 🇸🇬\n'
f'**4️⃣GB RAM, 2 Core:** `IDR 55.000` 🇸🇬\n'
f'**8️⃣GB RAM, 4 Core:** `IDR 65.000` 🇸🇬\n'
f'**↪️ Gratis Instalasi & Garansi 30 Hari**\n'
f'**↪️ Setup Siap Pakai, Skrip Siap Dijual**\n'
f'**↪️ Dengan Konfigurasi Lengkap**\n'
f'**═════════════════════════**\n',
buttons=[[
    Button.url("ORDER NOW ?", "https://t.me/DaffVpnStore")
]])